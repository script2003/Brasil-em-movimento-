import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import AppBrasilEmMovimento from './AppBrasilEmMovimento';

ReactDOM.createRoot(document.getElementById('root')).render(<AppBrasilEmMovimento />);